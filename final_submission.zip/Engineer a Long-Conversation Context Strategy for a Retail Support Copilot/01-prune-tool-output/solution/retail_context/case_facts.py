"""Case-facts extraction into a persistent block at the top of context.

Extraction is LLM-driven: one Claude call against the full transcript that returns
strict JSON for the 12 required fields. This is commonly called a *scratchpad* — same
concept, different word: a dense structured block that survives compression and is
placed at the top boundary of context so the model can recover transactional facts
without scanning thousands of tokens of narrative.

Missing-field behavior raises `CaseFactExtractionError` listing the gaps — silent
null-fill is forbidden.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from retail_context.client import complete_with_system, get_model
from retail_context.transcript import Transcript


# 12-field contract for the case-facts block.
REQUIRED_FIELDS: tuple[str, ...] = (
    "customer_id",
    "refund_order_id",
    "refund_amount_usd",
    "refund_status",
    "subscription_id",
    "subscription_plan",
    "subscription_cancel_reason",
    "subscription_status",
    "active_payment_method_last4",
    "new_payment_method_last4",
    "payment_update_failure_code",
    "payment_update_status",
)


@dataclass
class CaseFacts:
    customer_id: str
    refund_order_id: str
    refund_amount_usd: float
    refund_status: str
    subscription_id: str
    subscription_plan: str
    subscription_cancel_reason: str
    subscription_status: str
    active_payment_method_last4: str
    new_payment_method_last4: str
    payment_update_failure_code: str
    payment_update_status: str

    def to_markdown(self) -> str:
        return (
            "# Case Facts\n\n"
            "**Customer**\n"
            f"- customer_id: {self.customer_id}\n\n"
            "**Refund (resolved)**\n"
            f"- refund_order_id: {self.refund_order_id}\n"
            f"- refund_amount_usd: {self.refund_amount_usd}\n"
            f"- refund_status: {self.refund_status}\n\n"
            "**Subscription (resolved)**\n"
            f"- subscription_id: {self.subscription_id}\n"
            f"- subscription_plan: {self.subscription_plan}\n"
            f"- subscription_cancel_reason: {self.subscription_cancel_reason}\n"
            f"- subscription_status: {self.subscription_status}\n\n"
            "**Payment update (active)**\n"
            f"- active_payment_method_last4: {self.active_payment_method_last4}\n"
            f"- new_payment_method_last4: {self.new_payment_method_last4}\n"
            f"- payment_update_failure_code: {self.payment_update_failure_code}\n"
            f"- payment_update_status: {self.payment_update_status}\n"
        )


class CaseFactExtractionError(ValueError):
    def __init__(self, missing: list[str], raw: dict[str, Any]):
        super().__init__(f"case-facts extraction missing required fields: {missing}")
        self.missing = missing
        self.raw = raw


# System prompt for strict JSON extraction.
_SYSTEM_PROMPT = f"""
Extract case facts from the supplied customer-service transcript.

Return EXACTLY ONE JSON object with these 12 keys:

{json.dumps(REQUIRED_FIELDS, indent=2)}

Rules:
- Every required key must be present.
- customer_id, refund_order_id, subscription_id, and all status/reason/failure-code
  fields must be strings.
- refund_amount_usd must be a JSON number.
- active_payment_method_last4 and new_payment_method_last4 must be strings,
  preserving zero-padding where applicable.
- Preserve status tokens verbatim from the transcript.
- Do not invent information.
- If a field is missing from the transcript, return null for that field.
- Output JSON only.
- Do not output prose.
- Do not output Markdown.
- Do not use code fences.
"""


def _parse_json(raw: str) -> dict[str, Any]:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1]
        if raw.rstrip().endswith("```"):
            raw = raw.rsplit("```", 1)[0]
    return json.loads(raw)


def extract(
    transcript: Transcript,
    *,
    model: str | None = None,
    log_path: Path | None = None,
) -> CaseFacts:
    # 1. Build the user message.
    user = f"Transcript:\n\n{transcript.full_text}"

    # 2. Call Claude.
    text, input_tokens, output_tokens = complete_with_system(
        _SYSTEM_PROMPT,
        user,
        model=model,
        max_tokens=2048,
    )

    # 3. Parse the JSON response.
    raw = _parse_json(text)

    # 4. Write the call artifact if requested.
    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)

        log_data = {
            "model": model if model is not None else get_model(),
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "raw": raw,
        }

        log_path.write_text(
            json.dumps(log_data, indent=2),
            encoding="utf-8",
        )

    # 5. Validate every required field.
    missing = [
        field_name
        for field_name in REQUIRED_FIELDS
        if field_name not in raw
        or raw[field_name] is None
        or raw[field_name] == ""
    ]

    if missing:
        raise CaseFactExtractionError(
            missing=missing,
            raw=raw,
        )

    # 6. Construct CaseFacts with explicit type conversions.
    return CaseFacts(
        customer_id=str(raw["customer_id"]),
        refund_order_id=str(raw["refund_order_id"]),
        refund_amount_usd=float(raw["refund_amount_usd"]),
        refund_status=str(raw["refund_status"]),
        subscription_id=str(raw["subscription_id"]),
        subscription_plan=str(raw["subscription_plan"]),
        subscription_cancel_reason=str(raw["subscription_cancel_reason"]),
        subscription_status=str(raw["subscription_status"]),
        active_payment_method_last4=str(
            raw["active_payment_method_last4"]
        ),
        new_payment_method_last4=str(
            raw["new_payment_method_last4"]
        ),
        payment_update_failure_code=str(
            raw["payment_update_failure_code"]
        ),
        payment_update_status=str(
            raw["payment_update_status"]
        ),
    )


def to_dict(facts: CaseFacts) -> dict[str, Any]:
    return asdict(facts)