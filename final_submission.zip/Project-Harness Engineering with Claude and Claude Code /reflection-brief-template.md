# Reflection Brief — Harness Engineering Capstone

**Name:** Sereena Sebastian

**Date:** 2026-09-29

---

## Environment

- **Model(s):** Claude-based systems evaluated through the project harness.
- **OS / Python:** Linux workspace environment; Python-based test suite.
- **Approx. API spend:** Not recorded in the submitted evidence artifacts.

---

# Part 1 — Per-system

## System 1 — Agentic loop

### 1. Loop control.

→ Loop control is implemented in `claims_intake/loop.py`, specifically the `run` function, with `ClaimSession` maintaining the claim state. The loop uses the structured `stop_reason` returned by the model and terminal tool outcomes such as `route_to_adjuster` and `escalate_to_human` to determine when processing is complete. The loop continues when the model returns `tool_use` and terminates when the model returns `end_turn` or when a terminal routing outcome has been reached. The Budget safety net (`budget.check()`) serves as the non-silent wall-clock and token fallback against unexpected non-termination; it is not the normal mechanism for deciding that a claim is complete.

### 2. Anti-pattern.

→ An avoided anti-pattern is allowing natural-language model prose such as `"I am done"` to control loop termination. If prose controlled termination, ordinary generated text could prematurely stop the workflow without the required structured terminal outcome. The implementation instead relies on structured `stop_reason` values and terminal tool outcomes. This makes termination a machine-checkable state transition rather than a decision based on arbitrary model-generated text.

### 3. Tool design.

→ The terminal routing tools `route_to_adjuster` and `escalate_to_human` represent explicit structured terminal outcomes. Their tool schemas make the routing decision machine-readable instead of asking the model to emit an arbitrary routing string. Structured tool errors also provide information that can be used to correct an invalid invocation, whereas a generic natural-language error would provide less machine-readable information for recovery. The terminal outcomes are represented in the System 1 claim artifacts under `evidence/system1_agentic_loop/`.

### 4. Your numbers.

→ The System 1 evidence contains **8 claim runs**, with the claim traces showing multi-turn processing rather than a single model call. The runs complete through the structured agentic loop, with claims taking approximately **3–6 turns** depending on the workflow. The automated System 1 suite verifies the loop behavior, including termination invariants and Budget safety net constraints. The important architectural point is that the number of turns is a consequence of the tool-use/termination state machine rather than a fixed number of model calls.

---

## System 2 — Context strategy

### 5. The reduction.

→ `evidence/system2_context_strategy/budget.json` records a raw baseline of **38,708 tokens** and an assembled context of **16,925 tokens**, giving a **56.28% reduction**. The reduction is achieved by compressing historical resolved material while preserving information that downstream reasoning needs exactly. The context-strategy test suite recorded **30 passed** in `evidence/system2_context_strategy/pytest_output.txt`.

### 6. Summarize vs preserve.

→ The strategy is to preserve information when downstream reasoning depends on its exact value, while summarizing historical material when only its stable outcome is required. The **Case Facts** and **Active issue** sections remain verbatim because they contain values that must survive exactly, including `AVS_MISMATCH`, `7782`, and `in_progress`. Resolved historical sections can be summarized because their final outcomes are sufficient, such as `$22.14` for the refund and `duplicate_charge` for the resolved subscription/charge issue. This produces an assembled context of **16,925 tokens** from a **38,708-token** baseline.

### 7. Facts block.

→ The evaluation evidence in `evidence/system2_context_strategy/eval.jsonl` and `eval_control.jsonl` demonstrates why the facts block cannot simply be removed to achieve a smaller prompt. In the failure-mode experiment, removing the Case Facts block causes **Q6** to regress because the exact structured token `in_progress` is no longer produced. This shows that context optimization is not only about reducing token count: information required for downstream answerability must be preserved even when it increases the active context size.

---

## System 3 — Claude Code config

### 8. Path-scoped rules.

→ Glob-scoped rules defined in `.claude/rules/` (e.g., matching `tests/**/*.py` or `src/components/**/*`) apply cross-cutting constraints uniformly to matching files distributed anywhere across the repository hierarchy. In contrast, a directory-level `CLAUDE.md` file only applies locally within its specific directory and immediate subdirectories. When test files or component modules are scattered across multiple isolated subdirectories, a single directory-level `CLAUDE.md` fails to govern those external paths, whereas glob rules guarantee repository-wide coverage and consistency. The configuration suite recorded **35 passed**.

### 9. Forked skill.

→ The deploy-check skill uses `context: fork` together with an explicit `allowed-tools` restriction. The forked context isolates the skill's execution context from the main conversation, while the restricted tool list limits the operations available to it. The skill is intended to be read-only and uses tools such as `Read`, `Grep`, and `Glob`, together with restricted Git/GitHub operations. Forking is therefore appropriate because the skill performs an isolated verification task rather than modifying the main working context or performing a deployment. This reduces the blast radius of an incorrect action or unintended inherited context.

### 10. Scope.

→ The project-level configuration is represented by the repository `CLAUDE.md` and the path-scoped rules under `.claude/rules/`. The project also contains configuration for commands and skills under `.claude/commands/` and `.claude/skills/`. The validator and directory-structure evidence distinguish these project configuration layers rather than treating all instructions as one undifferentiated scope. The important invariant is that rules apply at the appropriate repository/path level rather than being silently treated as universal instructions.

---

## System 4 — Orchestration

### 11. Push work down.

→ System 4 pushes data filtering down into the SQL-backed storage layer through `store.defects_since(<timestamp>, limit=<N>)` rather than loading the entire defect history into the model and filtering it afterward. The automated tests include `test_defects_since_empty_month_and_does_not_load_full_table`, `test_defects_since_respects_limit`, and `test_gather_new_defects_is_pure_through_sql`. This means the timestamp filtering and result limit are applied before the model receives the data. The model therefore works with the relevant defect slice instead of the full historical table.

### 12. Crash recovery.

→ Recovery uses a **30-minute freshness threshold**. The recovery tests verify the boundary behavior: state at **29 minutes** is resumed, state at **30 minutes** is still resumed, while state at **31 minutes** is treated as stale and starts fresh. A completed state also starts fresh rather than being resumed. This resume-versus-fresh decision prevents stale intermediate state from being carried indefinitely while still allowing sufficiently recent work to continue. When a fresh execution is required, the relevant summary can be injected so that useful high-level findings are preserved without restoring obsolete execution state.

### 13. Small state.

→ `evidence/system4_orchestration/hot_state_size.txt` records a hot-state size of **643 bytes** for `data/hot_state.json`. Keeping persistent hot state small prevents repeated shift executions from accumulating an ever-growing serialized session. Instead, durable state contains only the information that needs to persist, while relevant defect data is retrieved through bounded queries such as `defects_since`. The orchestration suite recorded **33 passed** in `evidence/system4_orchestration/shift_run_output.txt`.

---

# Part 2 — Synthesis

## 14. Three layers.

→ The three system layers follow a clear architectural hierarchy:

- **Orchestration layer:** `recovery.py`, `fork.py`, and storage/retrieval logic (`warm.py`, `cold.py`) manage persistent workflow state, crash recovery, hypothesis isolation, and bounded SQL defect retrieval.
- **Model layer:** `claims_intake/loop.py` sits under orchestration to execute the Claude interaction, driving control flow through structured `stop_reason` signals and tool execution.
- **Harness layer:** `CLAUDE.md`, `.claude/rules/`, `.claude/commands/`, and `.claude/skills/` define deterministic configuration boundaries, tool interfaces, and repository-wide constraints governing model execution.

The separation matters because model reasoning, deterministic constraints, and longer-lived workflow state have different responsibilities.

## 15. Deterministic vs prompt.

→ Deterministic enforcement is used where violating a rule would compromise state integrity, safety, or permissions. For example, System 1 does not allow natural-language text such as `"I am done"` to terminate the loop; termination is controlled by structured `stop_reason` values and terminal tool outcomes. System 4 also deterministically enforces the **30-minute** recovery threshold. In System 3, the forked skill's `allowed-tools` list deterministically limits the operations available to the skill.

Prompt-based guidance is instead useful for higher-level reasoning and instructions where some flexibility is desirable. For example, `.claude/commands/review.md` provides review guidance rather than implementing every review decision as a hard-coded program rule. The distinction is that deterministic mechanisms enforce invariants, while prompts guide model reasoning.

## 16. Context, two faces.

→ System 2 manages **intra-session context** by reducing the active context from **38,708 tokens to 16,925 tokens**, a **56.28% reduction**, while preserving exact facts required for downstream answerability.

System 4 manages **cross-execution context** by keeping persistent hot state at only **643 bytes** and retrieving relevant historical defect information through bounded `defects_since` queries rather than carrying the complete defect history forward.

Both systems apply the same general principle: retain information that future reasoning actually needs while compressing, externalizing, or discarding information that does not need to remain active. The difference is that System 2 manages the model's current context window, while System 4 manages state across repeated executions.

## 17. Reliability you can't see in one run.

→ The orchestration suite tests properties that a single successful execution would not necessarily reveal. For example, `test_fork_for_hypothesis_copies_state_without_mutating_base` verifies that creating a hypothesis fork does not mutate the original state, while `test_two_forks_produce_independent_scratchpads` verifies that two simultaneous hypotheses do not accidentally share mutable scratchpad state. A single successful investigation could appear correct even if those two hypotheses were sharing state internally. The automated suite exposes these isolation invariants across controlled test cases rather than relying on one successful run.

## 18. Blast radius.

→ System 1 has a potentially large workflow impact because its terminal outcomes determine how a claims-intake case is routed. The implementation limits that impact through structured terminal tools, structured `stop_reason` handling, explicit claim state, and the Budget safety net guard.

System 3 similarly limits the blast radius of a Claude Code skill through `context: fork` and an explicit `allowed-tools` list. Instead of allowing a skill to inherit unrestricted context and permissions, the configuration constrains the environment in which it operates. These mechanisms demonstrate that reliability is not only about producing a correct answer; it is also about limiting what an incorrect model action can affect.

---

# Part 3 — Honest assessment

## 19. What broke.

→ The main implementation systems did not fail their required automated verification. The documented test evidence shows **30 passed** for System 2, **35 passed** for System 3, and **33 passed** for System 4, while System 1 also has its automated test evidence and claim traces.

One environment-level problem occurred during final packaging when the shell reported `bash: zip: command not found`. This was a workspace/tooling issue rather than a project-test failure. The lesson is that packaging should be treated as a separate final verification step instead of assuming that a working project environment also has every packaging utility installed.

## 20. What you'd change.

→ I would add a final automated submission-validation step. The project already verifies the individual systems, but the final package should also be checked before submission to ensure that the source files, reflection brief, README files, pytest outputs, and evidence artifacts are all present and that references in the documentation point to real artifacts.

For example, the final validation should check that every referenced evidence file exists and that the reflection brief is included in the submission package. This would reduce the risk of submitting a technically correct implementation with incomplete or inconsistent packaging/evidence.