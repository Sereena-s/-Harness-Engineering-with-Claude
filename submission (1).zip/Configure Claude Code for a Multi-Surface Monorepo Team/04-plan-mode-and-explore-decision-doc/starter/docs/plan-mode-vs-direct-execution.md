# Plan mode vs. direct execution — team decision guide

Choosing between Claude Code's **plan mode** (investigate and propose before changing anything) and **direct execution** (change code immediately) is the single biggest leverage point in how the team uses the harness day-to-day. The wrong mode at either extreme costs us: plan mode for trivial fixes is friction; direct execution for architectural changes burns context and produces rework.

> "Software engineering is rapidly evolving into a discipline of plan and review. The developer's primary role shifts from writing raw keystrokes to evaluating proposed execution plans and verifying output correctness."
> — **Jack Knight-Webb**, *SWE Is Becoming Plan and Review* (Module 8 Anchor Talk)

This doc walks four concrete decisions against our codebase: one plan-mode example, one direct-execution example, one Explore-subagent example, and one combined-workflow example.

---

## 1. Plan-mode example

### Scenario
Extracting a shared custom hook into a new hook file under the hooks directory from three React components that currently duplicate cart state management:
- `src/components/Cart/Cart.tsx`
- `src/components/Checkout/Checkout.tsx`
- `src/components/MiniCart/MiniCart.tsx`

### Why Plan Mode?
- **Multiple Files Touched:** Affects 3 existing components plus a brand-new hook module (created as `src/hooks/useCart.ts` during execution).
- **Multiple Valid Approaches:** Cart state could use local React state, a Context provider, or an external state manager.
- **Architectural & Cross-Cutting Impact:** Changing state management across components risks state synchronization bugs or unnecessary re-renders.

### Value of Planning
Planning before committing code serves to **prevent costly rework**. By discussing interface contracts, return shapes, and side-effects in plan mode before writing code, the team agrees on the design upfront rather than refactoring multiple broken components after execution.

---

## 2. Direct-execution example

### Scenario
Adding a `min: 0` validation to the order quantity field inside `src/api/orders/handler.ts` (or schema definition file).

### Why Direct Execution?
- **Single, Well-Scoped Change:** Touches only one function/schema file in a localized place.
- **Predictable Diff:** You (the developer) already know the exact line of code to add before invoking Claude.

### The Bar for Direct Execution
If you can describe the exact change in one sentence and accurately predict the patch before typing, skip planning and execute directly.

---

## 3. Explore-subagent example

### Scenario
Running an inventory search: "Find every location in the codebase where `processRefund` is called." The search spans `src/api/orders/refund.ts`, `src/api/billing/issue.ts`, and `src/services/payment.ts`.

### Why Explore Subagent?
- **Isolating Verbose Output:** Running broad searches across multiple files produces large grep logs and file traces.
- **Preserving Main Context:** Using a subagent isolates intermediate search logs, returning only a succinct summary to the primary conversation window.

### The Scratchpad Pattern
To prevent losing findings during long sessions, the subagent uses the **scratchpad pattern** (from the Architect's Playbook). The subagent writes its active inventory notes to a file (e.g. `tmp/refund-callsites.md`). This guarantees that the complete call-site inventory survives context window truncations in the main session.

---

## 4. Combined workflow — plan mode for investigation, then direct execution

### Scenario
Renaming `ordersRepo.findById` to `ordersRepo.getById` across `src/db/orders.ts` to align with the team naming convention (`get*` for single-row reads, `find*` for multi-row queries).

### Why a Combined Workflow?
This approach combines **plan mode for investigation** with **direct execution for implementation**. Developers often mistake plan mode and direct execution as a binary choice, but pairing them leverages the strengths of both: investigation requires discovery, while renaming is purely mechanical.

### The 3-Step Execution Flow
1. **Step 1 — Investigation (Plan Mode):** Claude scans the codebase to find every call site of `ordersRepo.findById` and checks for dynamic string lookups that a basic grep might miss. Claude presents a plan containing the verified list of files to update.
2. **Step 2 — Approval:** The developer reviews and approves the targeted call-site list and proposed plan.
3. **Step 3 — Mechanical Edit (Direct Execution):** Switch to direct execution to mechanically apply the function renaming across all files and run the test suite to confirm zero regressions.

---

## Quick reference

| Situation | Mode |
|-----------|------|
| Single function, fix is obvious, you can predict the diff | Direct execution |
| Multi-file refactor, API shape is debatable | Plan mode |
| Discovery / inventory across the codebase, you'll throw away the intermediate steps | Explore subagent |
| Investigation-then-mechanical-change | Plan mode → direct execution |
| Architectural decision (which database, which queue) | Plan mode, possibly with a fork to compare options |

When in doubt: plan mode is recoverable (you can switch to execution), but direct execution on a complex change is not. Default to plan when uncertain.