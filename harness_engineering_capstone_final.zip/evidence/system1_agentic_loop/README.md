# System 1 Evidence — Agentic Claims Intake

## Purpose

Evidence for the `stop_reason`-driven claims-intake agentic loop.

## Automated test log

`pytest_output.txt`

The test log records the automated verification of loop-control behavior, tool outcomes, fixtures, and termination-related cases.

## Run artifacts

- `claim_01_kitchen_fire.jsonl`
- `claim_04_neighbor_injury.jsonl`
- `claim_05_auto_collision.jsonl`
- `claim_06_fence_deescalation.jsonl`
- `claim_07_tree_falls_on_car.jsonl`
- `claim_08_minor_por_ch_damage.jsonl`
- `summary.md`

## Reflection reference

See `reflection-brief.md`, Part 1, Section 1 — Loop Control Location & Termination Logic.

## Key invariant

Natural-language model prose such as `"I am done"` is not used as the termination signal.

Structured `stop_reason` values and terminal tool outcomes provide the primary loop-control mechanism. Terminal outcomes include `route_to_adjuster` and `escalate_to_human`.

The maximum-turn guard is a safety fallback against unexpected non-termination and is not the primary termination mechanism.

## Verification note

The pytest log records the actual automated test execution. Test counts and outcomes should not be manually edited.