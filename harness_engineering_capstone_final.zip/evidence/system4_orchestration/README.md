# System 4 Evidence — Quality Orchestration

## Purpose

Evidence for tiered state, SQL-filtered defect retrieval, crash recovery, and fork-specific investigation state.

## Automated test log

`pytest_output.txt`

The test log records the automated verification of tiered state behavior, SQL-filtered defect retrieval, invocation flow, crash recovery, freshness thresholds, and fork/scratchpad isolation.

## Run artifacts

- `shift_run_output.txt`
- `hot_state_size.txt`
- `scratchpad_line.jsonl`

## Reflection reference

See `reflection-brief.md`, Part 1, Section 4 — Quality Orchestration & State Persistence.

## Key results

- Hot state size: 643 bytes
- `defects_since` uses timestamp-filtered retrieval with an explicit result limit.
- Recovery uses a 30-minute freshness threshold.
- Fork investigations use independent scratchpads.
- Fork creation does not mutate the base investigation.
- Selected findings can be merged without rewriting existing findings.

## SQL-filtered slice evidence

The automated test suite verifies the SQL-backed `defects_since` path.

Relevant tests include:

- `test_defects_since_empty_month_and_does_not_load_full_table`
- `test_defects_since_respects_limit`
- `test_gather_new_defects_is_pure_through_sql`

The recorded test execution verifies the bounded form:

`store.defects_since(<timestamp>, limit=<N>)`

This verifies that defect retrieval is performed through the filtered SQL-backed path rather than loading the full defect table.

## Crash recovery evidence

The automated suite verifies the recovery freshness threshold, including the 30-minute threshold constant and fresh/stale recovery decisions.

Relevant tests include:

- `test_threshold_constant_is_30_minutes`
- `test_recovery_decide_truth_table[...]`
- `test_recovery_decide_empty_manifest_is_fresh`
- `test_resumed_prompt_has_both_sections`

## Fork isolation evidence

The automated suite verifies that:

- a fork copies hypothesis state without mutating the base;
- two forks produce independent scratchpads;
- findings can be merged without rewriting existing findings.

Relevant tests include:

- `test_fork_for_hypothesis_copies_state_without_mutating_base`
- `test_two_forks_produce_independent_scratchpads`
- `test_merge_findings_appends_without_rewriting_existing`

## Verification note

The pytest log records the actual automated test execution. Test counts and outcomes should not be manually edited.