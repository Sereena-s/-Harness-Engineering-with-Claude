# System 2 Evidence — Context Strategy

## Purpose

Evidence for reducing active context size while preserving information required for downstream answerability.

## Automated test log

`pytest_output.txt`

The test log records the automated verification of the context assembly, compression strategy, preservation rules, and downstream evaluation behavior.

## Run artifacts

- `budget.json`
- `context.md`
- `case_facts_call.json`
- `eval.jsonl`
- `eval_control.jsonl`

## Reflection reference

See `reflection-brief.md`, Part 1, Section 2 — Context Strategy & Token Compression.

## Key results

- Raw baseline: 38,708 tokens
- Assembled context: 16,925 tokens
- Reduction: 56.28%

Case facts and active issue fields are preserved because they are required for downstream answerability.

The preserved information includes exact fields such as `AVS_MISMATCH`, `7782`, and `in_progress`.

Resolved historical material can be compressed when downstream reasoning only requires the stable final outcome, such as `$22.14` or `duplicate_charge`.

## Failure-mode experiment

Removing the case-facts block causes Q6 to regress and no longer produces the exact structured token `in_progress`.

This demonstrates that context compression must preserve information required for downstream evaluation rather than optimizing token count alone.

## Verification note

The pytest log records the actual automated test execution. Test counts and outcomes should not be manually edited.