# System 3 Evidence — Claude Code Configuration

## Purpose

Evidence for hierarchical Claude Code configuration, path-scoped rules, commands, skills, and configuration validation.

## Automated test log

`pytest_output.txt`

The test log records the automated verification of configuration hierarchy, path-scoped rules, skills, tool restrictions, and configuration validation.

## Run artifacts

- `CLAUDE.md`
- `claude_dir_structure.txt`
- `validator_output.txt`
- `evidence_rule_claude.md`
- `evidence_rule_api.md`
- `evidence_rule_react.md`
- `evidence_rule_review.md`
- `evidence_rule_skill.md`
- `evidence_rule_tests.md`

## Reflection reference

See `reflection-brief.md`, Part 1, Section 3 — Claude Code Configuration Verification.

## Key invariant

Repository behavior is constrained through explicit configuration hierarchy, path-scoped rules, skills, commands, and tool restrictions rather than relying only on natural-language instructions.

Path-scoped rules apply constraints to the relevant code-directory boundaries, while skills provide modular capabilities for domain-specific actions.

## Verification note

The pytest log records the actual automated test execution. Test counts and outcomes should not be manually edited.