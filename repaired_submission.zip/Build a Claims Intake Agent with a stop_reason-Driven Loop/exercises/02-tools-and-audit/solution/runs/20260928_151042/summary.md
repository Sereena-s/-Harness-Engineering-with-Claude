# Run summary — 20260928_151042

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.0699** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 3086 | 717 | 0.0067 | 6.8 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 2866 | 576 | 0.0057 | 6.3 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 2909 | 587 | 0.0058 | 5.8 |
| claim_04_neighbor_injury | incomplete | - | - | 4 | 0 | 6966 | 970 | 0.0118 | 11.0 |
| claim_05_auto_collision | incomplete | - | - | 3 | 0 | 6059 | 1211 | 0.0121 | 11.0 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 4483 | 755 | 0.0083 | 8.3 |
| claim_07_tree_falls_on_car | incomplete | - | - | 4 | 0 | 7676 | 944 | 0.0124 | 10.0 |
| claim_08_minor_porch_damage | incomplete | - | - | 3 | 0 | 4320 | 547 | 0.0071 | 7.4 |
