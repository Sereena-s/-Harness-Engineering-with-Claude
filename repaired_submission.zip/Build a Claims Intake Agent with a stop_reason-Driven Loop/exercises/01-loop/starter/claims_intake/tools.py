"""Tool schemas and dispatcher.

Seven tools, registered with Anthropic tool-use shape. The dispatcher returns
serialized JSON strings to be wrapped as `tool_result` content. Errors follow
the Playbook "Graceful Tool Failure" shape:

    {"is_error": true,
     "error_category": "transient"|"permanent",
     "is_retryable": bool,
     "message": "..."}

Errors are never raised to the loop.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from claims_intake.session import ClaimSession

CLAIM_TYPES = ["property_damage", "theft", "liability", "auto"]
SEVERITIES = ["low", "medium", "high"]

# ----------------------------------------------------------------------------
# Schemas — passed verbatim to the Anthropic Messages API as the `tools` arg.
# ----------------------------------------------------------------------------

TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "lookup_policy",
        "description": "Looks up and returns the policy record associated with a given policy ID. Call this early in the conversation.",
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_id": {
                    "type": "string",
                    "description": "The unique policy identifier string."
                }
            },
            "required": ["policy_id"]
        }
    },
    {
        "name": "record_claim_fact",
        "description": "Records one individual normalized fact about the claim (e.g. incident_date, location, items_lost, root_cause).",
        "input_schema": {
            "type": "object",
            "properties": {
                "field": {
                    "type": "string",
                    "description": "The name of the fact attribute being recorded."
                },
                "value": {
                    "type": "string",
                    "description": "The value for the specified fact attribute."
                }
            },
            "required": ["field", "value"]
        }
    },
    {
        "name": "classify_claim",
        "description": "Commits the model to a claim type classification along with a confidence score and rationale.",
        "input_schema": {
            "type": "object",
            "properties": {
                "claim_type": {
                    "type": "string",
                    "enum": CLAIM_TYPES,
                    "description": "The primary category of the claim."
                },
                "confidence": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                    "description": "Confidence score between 0.0 and 1.0."
                },
                "rationale": {
                    "type": "string",
                    "description": "Explanation justifying the claim classification."
                }
            },
            "required": ["claim_type", "confidence", "rationale"]
        }
    },
    {
        "name": "assess_severity",
        "description": "Commits the model to a severity level assessment for the claim.",
        "input_schema": {
            "type": "object",
            "properties": {
                "severity": {
                    "type": "string",
                    "enum": SEVERITIES,
                    "description": "The severity level bucket for the claim."
                },
                "rationale": {
                    "type": "string",
                    "description": "Explanation justifying the severity assessment."
                }
            },
            "required": ["severity", "rationale"]
        }
    },
    {
        "name": "request_clarification",
        "description": "Requests clarification from the claimant when critical information is missing or when the claim type is ambiguous.",
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The clarification question to ask the claimant."
                },
                "ambiguity_between": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    },
                    "description": "List of candidate claim types or interpretations causing ambiguity (must have at least 2 items)."
                }
            },
            "required": ["question", "ambiguity_between"]
        }
    },
    {
        "name": "route_to_adjuster",
        "description": "Terminal tool. Routes the claim to an adjuster queue. Requires classification (with confidence >= 0.6) and severity assessment.",
        "input_schema": {
            "type": "object",
            "properties": {
                "queue": {
                    "type": "string",
                    "enum": CLAIM_TYPES,
                    "description": "The adjuster queue to route the claim to."
                },
                "claim_summary": {
                    "type": "string",
                    "description": "Summary of the claim details for the adjuster."
                }
            },
            "required": ["queue", "claim_summary"]
        }
    },
    {
        "name": "escalate_to_human",
        "description": "Terminal tool. Escalates the claim to a human representative when confidence is low or the claim cannot be safely routed.",
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Reason for escalating to human intervention."
                },
                "structured_summary": {
                    "type": "object",
                    "properties": {
                        "policy_id": {"type": "string"},
                        "root_cause": {"type": "string"},
                        "candidate_claim_types": {
                            "type": "array",
                            "items": {"type": "string"}
                        },
                        "case_facts": {"type": "object"},
                        "recommended_action": {"type": "string"},
                        "confidence": {"type": "number"}
                    },
                    "required": [
                        "policy_id",
                        "root_cause",
                        "candidate_claim_types",
                        "case_facts",
                        "recommended_action",
                        "confidence"
                    ],
                    "description": "Structured overview of the claim context for the human reviewer."
                }
            },
            "required": ["reason", "structured_summary"]
        }
    }
]

# ----------------------------------------------------------------------------
# Errors — Graceful Tool Failure shape
# ----------------------------------------------------------------------------


def _err(category: str, retryable: bool, message: str) -> str:
    return json.dumps({
        "is_error": True,
        "error_category": category,
        "is_retryable": retryable,
        "message": message
    })


def _ok(payload: dict[str, Any]) -> str:
    return json.dumps(payload)


# ----------------------------------------------------------------------------
# Tool implementations
# ----------------------------------------------------------------------------


def _t_lookup_policy(session: ClaimSession, inp: dict[str, Any]) -> str:
    policy_id = inp.get("policy_id")
    if not isinstance(policy_id, str):
        return _err("permanent", False, "policy_id must be a string")
    
    if policy_id not in session.policies:
        return _err("permanent", False, f"Policy ID '{policy_id}' not found")
    
    policy = session.policies[policy_id]
    return _ok(policy)


def _t_record_claim_fact(session: ClaimSession, inp: dict[str, Any]) -> str:
    field = inp.get("field")
    value = inp.get("value")
    
    if not isinstance(field, str) or not isinstance(value, str):
        return _err("permanent", False, "field and value must both be strings")
    
    session.case_facts[field] = value
    return _ok({
        "recorded": True,
        "field": field,
        "case_facts_count": len(session.case_facts)
    })


def _t_classify_claim(session: ClaimSession, inp: dict[str, Any]) -> str:
    claim_type = inp.get("claim_type")
    confidence = inp.get("confidence")
    rationale = inp.get("rationale")
    
    if claim_type not in CLAIM_TYPES:
        return _err("permanent", False, f"claim_type must be one of {CLAIM_TYPES}")
    if not isinstance(confidence, (int, float)) or not (0.0 <= confidence <= 1.0):
        return _err("permanent", False, "confidence must be a float/number in [0.0, 1.0]")
    if not isinstance(rationale, str):
        return _err("permanent", False, "rationale must be a string")
    
    session.classification = {
        "claim_type": claim_type,
        "confidence": float(confidence),
        "rationale": rationale
    }
    return _ok({
        "recorded": True,
        "claim_type": claim_type,
        "confidence": confidence,
        "rationale": rationale
    })


def _t_assess_severity(session: ClaimSession, inp: dict[str, Any]) -> str:
    severity = inp.get("severity")
    rationale = inp.get("rationale")
    
    if severity not in SEVERITIES:
        return _err("permanent", False, f"severity must be one of {SEVERITIES}")
    if not isinstance(rationale, str):
        return _err("permanent", False, "rationale must be a string")
    
    session.severity = {
        "severity": severity,
        "rationale": rationale
    }
    return _ok({
        "recorded": True,
        "severity": severity,
        "rationale": rationale
    })


def _t_request_clarification(session: ClaimSession, inp: dict[str, Any]) -> str:
    question = inp.get("question")
    ambiguity_between = inp.get("ambiguity_between")
    
    if not isinstance(question, str):
        return _err("permanent", False, "question must be a string")
    if not isinstance(ambiguity_between, list) or len(ambiguity_between) < 2:
        return _err("permanent", False, "ambiguity_between must be a list containing at least 2 items")
    
    session.clarifications_asked.append({
        "question": question,
        "ambiguity_between": ambiguity_between
    })
    
    question_lower = question.lower()
    for key, response in session.clarification_responses.items():
        if key.lower() in question_lower:
            return _ok({"claimant_reply": response})
            
    return _ok({"claimant_reply": "NO_RESPONSE"})


def _t_route_to_adjuster(session: ClaimSession, inp: dict[str, Any]) -> str:
    if session.terminal_called:
        return _err("permanent", False, "A terminal tool has already been called for this session")
    
    queue = inp.get("queue")
    claim_summary = inp.get("claim_summary")
    
    if queue not in CLAIM_TYPES:
        return _err("permanent", False, f"queue must be one of {CLAIM_TYPES}")
    if not isinstance(claim_summary, str):
        return _err("permanent", False, "claim_summary must be a string")
        
    if not session.classification or not session.severity:
        return _err("permanent", False, "Both classification and severity must be assessed prior to routing")
    
    session.terminal_called = True
    
    record = {
        "claim_id": session.claim_id,
        "policy_id": session.policy_id,
        "claim_type": session.classification["claim_type"],
        "severity": session.severity["severity"],
        "confidence": session.classification["confidence"],
        "rationale": session.classification["rationale"],
        "claim_summary": claim_summary,
        "case_facts": session.case_facts
    }
    session.routing = record
    
    queue_file = session.run_dir / "queues" / f"{queue}.jsonl"
    _append_jsonl(queue_file, record)
    
    return _ok({"routed": True, "queue": queue})


def _t_escalate_to_human(session: ClaimSession, inp: dict[str, Any]) -> str:
    if session.terminal_called:
        return _err("permanent", False, "A terminal tool has already been called for this session")
    
    reason = inp.get("reason")
    structured_summary = inp.get("structured_summary")
    
    if not isinstance(reason, str):
        return _err("permanent", False, "reason must be a string")
    if not isinstance(structured_summary, dict):
        return _err("permanent", False, "structured_summary must be a dict")
        
    required_keys = [
        "policy_id",
        "root_cause",
        "candidate_claim_types",
        "case_facts",
        "recommended_action",
        "confidence"
    ]
    missing_keys = [k for k in required_keys if k not in structured_summary]
    if missing_keys:
        return _err("permanent", False, f"structured_summary is missing required fields: {', '.join(missing_keys)}")
    
    session.terminal_called = True
    
    record = {
        "claim_id": session.claim_id,
        "policy_id": session.policy_id,
        "reason": reason,
        **structured_summary,
        "case_facts_at_escalation": session.case_facts
    }
    session.escalation = record
    
    escalation_file = session.run_dir / "escalations.jsonl"
    _append_jsonl(escalation_file, record)
    
    return _ok({"escalated": True})


# ----------------------------------------------------------------------------
# Dispatcher
# ----------------------------------------------------------------------------


_DISPATCH = {
    "lookup_policy": _t_lookup_policy,
    "record_claim_fact": _t_record_claim_fact,
    "classify_claim": _t_classify_claim,
    "assess_severity": _t_assess_severity,
    "request_clarification": _t_request_clarification,
    "route_to_adjuster": _t_route_to_adjuster,
    "escalate_to_human": _t_escalate_to_human,
}


def make_executor(session: ClaimSession) -> Executor:
    """Return a ToolExecutor callable bound to this session."""

    def execute(name: str, tool_input: dict[str, Any]) -> str:
        handler = _DISPATCH.get(name)
        if handler is None:
            return _err("permanent", False, f"unknown tool: {name}")
        try:
            return handler(session, tool_input)
        except Exception as exc:
            # Defensive: anything raised inside a handler becomes a graceful error,
            # never crashes the loop.
            return _err("transient", True, f"{type(exc).__name__}: {exc}")

    return execute


# Type alias for clarity; the loop only sees a Callable.
Executor = Any


def _append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")