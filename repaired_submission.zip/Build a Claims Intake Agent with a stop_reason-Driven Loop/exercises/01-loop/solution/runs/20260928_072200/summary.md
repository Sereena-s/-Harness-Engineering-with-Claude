# Run summary — 20260928_072200

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1167** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 4 | 0 | 10514 | 1358 | 0.0173 | 14.3 |
| claim_02_stolen_bike | incomplete | - | - | 5 | 0 | 12916 | 1211 | 0.019 | 14.7 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 3916 | 581 | 0.0068 | 5.9 |
| claim_04_neighbor_injury | incomplete | - | - | 4 | 0 | 9588 | 1278 | 0.016 | 15.1 |
| claim_05_auto_collision | incomplete | - | - | 3 | 0 | 7864 | 1277 | 0.0142 | 14.1 |
| claim_06_low_confidence_escalation | incomplete | - | - | 4 | 1 | 9804 | 1413 | 0.0169 | 16.0 |
| claim_07_tree_falls_on_car | incomplete | - | - | 4 | 0 | 9346 | 1137 | 0.015 | 12.8 |
| claim_08_minor_porch_damage | incomplete | - | - | 3 | 0 | 6915 | 904 | 0.0114 | 9.6 |
