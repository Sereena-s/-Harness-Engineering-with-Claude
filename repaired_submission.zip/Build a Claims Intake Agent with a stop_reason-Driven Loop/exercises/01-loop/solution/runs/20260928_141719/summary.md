# Run summary — 20260928_141719

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1313** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 5 | 0 | 14438 | 1552 | 0.0222 | 15.7 |
| claim_02_stolen_bike | incomplete | - | - | 5 | 0 | 11787 | 1214 | 0.0179 | 15.5 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 3811 | 477 | 0.0062 | 5.1 |
| claim_04_neighbor_injury | incomplete | - | - | 5 | 0 | 12124 | 1285 | 0.0185 | 14.0 |
| claim_05_auto_collision | incomplete | - | - | 5 | 0 | 14403 | 1553 | 0.0222 | 18.5 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 4101 | 681 | 0.0075 | 6.8 |
| claim_07_tree_falls_on_car | incomplete | - | - | 6 | 0 | 14760 | 1251 | 0.021 | 15.2 |
| claim_08_minor_porch_damage | incomplete | - | - | 4 | 0 | 10088 | 1154 | 0.0159 | 12.2 |
