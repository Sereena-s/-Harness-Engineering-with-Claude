# Run summary — 20260928_145426

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1193** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 4 | 0 | 10862 | 1330 | 0.0175 | 13.4 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 3855 | 554 | 0.0066 | 6.0 |
| claim_03_water_damage | routed | property_damage | high | 4 | 0 | 9073 | 1100 | 0.0146 | 12.0 |
| claim_04_neighbor_injury | routed | liability | medium | 5 | 0 | 11952 | 1214 | 0.018 | 14.1 |
| claim_05_auto_collision | routed | auto | high | 3 | 0 | 7820 | 1264 | 0.0141 | 14.4 |
| claim_06_low_confidence_escalation | escalated | property_damage,auto,liability | - | 4 | 1 | 10289 | 1539 | 0.018 | 16.4 |
| claim_07_tree_falls_on_car | routed | auto | medium | 4 | 0 | 9792 | 1073 | 0.0152 | 12.4 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 9966 | 1056 | 0.0152 | 11.2 |
