# Run summary — 20260928_144447

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1115** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 4 | 0 | 10680 | 1275 | 0.0171 | 12.9 |
| claim_02_stolen_bike | routed | theft | low | 4 | 0 | 9789 | 1076 | 0.0152 | 13.0 |
| claim_03_water_damage | incomplete | - | - | 3 | 0 | 5671 | 556 | 0.0085 | 6.4 |
| claim_04_neighbor_injury | routed | liability | medium | 4 | 0 | 10547 | 1207 | 0.0166 | 12.6 |
| claim_05_auto_collision | routed | auto | high | 3 | 0 | 8037 | 1288 | 0.0145 | 14.3 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 4108 | 862 | 0.0084 | 8.8 |
| claim_07_tree_falls_on_car | routed | auto | medium | 5 | 0 | 11544 | 1103 | 0.0171 | 13.3 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 9200 | 1022 | 0.0143 | 19.7 |
