# Run summary — 20260928_141307

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1236** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 5 | 0 | 14383 | 1451 | 0.0216 | 14.2 |
| claim_02_stolen_bike | incomplete | - | - | 4 | 0 | 8636 | 957 | 0.0134 | 11.9 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 3908 | 546 | 0.0066 | 5.7 |
| claim_04_neighbor_injury | incomplete | - | - | 6 | 0 | 16250 | 1834 | 0.0254 | 20.0 |
| claim_05_auto_collision | incomplete | - | - | 4 | 0 | 11396 | 1483 | 0.0188 | 16.7 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 3395 | 343 | 0.0051 | 5.0 |
| claim_07_tree_falls_on_car | incomplete | - | - | 5 | 0 | 12482 | 1130 | 0.0181 | 13.1 |
| claim_08_minor_porch_damage | incomplete | - | - | 4 | 0 | 9272 | 1028 | 0.0144 | 10.5 |
