# Run summary — 20260928_145008

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1103** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 4 | 0 | 10318 | 1181 | 0.0162 | 12.2 |
| claim_02_stolen_bike | routed | theft | medium | 4 | 0 | 9827 | 1166 | 0.0157 | 13.9 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 3809 | 503 | 0.0063 | 5.8 |
| claim_04_neighbor_injury | routed | liability | medium | 5 | 0 | 12121 | 1310 | 0.0187 | 14.4 |
| claim_05_auto_collision | routed | auto | high | 5 | 0 | 13023 | 1444 | 0.0202 | 17.5 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 4104 | 706 | 0.0076 | 7.5 |
| claim_07_tree_falls_on_car | routed | auto | high | 4 | 0 | 9687 | 1011 | 0.0147 | 11.2 |
| claim_08_minor_porch_damage | incomplete | - | - | 3 | 0 | 6865 | 795 | 0.0108 | 8.4 |
