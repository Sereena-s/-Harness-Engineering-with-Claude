# Run summary — 20260926_144009

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1002** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6270 | 463 | 0.0086 | 5.9 |
| claim_02_stolen_bike | incomplete | - | - | 3 | 0 | 9149 | 452 | 0.0114 | 5.3 |
| claim_03_water_damage | incomplete | - | - | 2 | 0 | 6204 | 461 | 0.0085 | 4.6 |
| claim_04_neighbor_injury | incomplete | - | - | 3 | 0 | 9258 | 521 | 0.0119 | 6.8 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14975 | 964 | 0.0198 | 11.3 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 9473 | 612 | 0.0125 | 7.1 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6189 | 438 | 0.0084 | 5.5 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14511 | 918 | 0.0191 | 10.2 |
