# Run summary — 20260926_061422

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1365** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6276 | 456 | 0.0086 | 4.8 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6158 | 419 | 0.0083 | 4.6 |
| claim_03_water_damage | routed | property_damage | medium | 6 | 1 | 22368 | 1195 | 0.0283 | 14.2 |
| claim_04_neighbor_injury | routed | liability | high | 5 | 0 | 17764 | 956 | 0.0225 | 12.5 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 15517 | 1034 | 0.0207 | 11.5 |
| claim_06_low_confidence_escalation | incomplete | - | - | 4 | 1 | 13397 | 757 | 0.0172 | 10.4 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6188 | 469 | 0.0085 | 5.7 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 18120 | 857 | 0.0224 | 10.1 |
