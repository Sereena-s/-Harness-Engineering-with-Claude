# Run summary — 20260926_060359

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1282** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6266 | 413 | 0.0083 | 7.5 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6158 | 455 | 0.0084 | 4.6 |
| claim_03_water_damage | routed | property_damage | high | 8 | 2 | 30383 | 1347 | 0.0371 | 17.3 |
| claim_04_neighbor_injury | routed | liability | high | 4 | 0 | 14633 | 926 | 0.0193 | 12.3 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14848 | 902 | 0.0194 | 9.8 |
| claim_06_low_confidence_escalation | incomplete | - | - | 2 | 0 | 6292 | 520 | 0.0089 | 6.6 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6282 | 456 | 0.0086 | 6.0 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14104 | 830 | 0.0183 | 10.3 |
