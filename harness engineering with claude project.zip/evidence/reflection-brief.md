# Reflection Brief — Harness Engineering Capstone

## Part 1 — System Architecture

12. **Crash recovery.**
    → A fresh start with an injected summary is often more reliable than resuming because full raw conversation logs can accumulate stale, conflicting, or corrupted context, leading to repetitive reasoning loops. Injecting a structured summary forces the model to operate on a clean slate with only verified state facts. In System 1, we observed this through `evidence/system1_agentic_loop/summary.md`, where structured state tracking allowed clean recovery across decomposition turns[cite: 10].

13. **Small state.**
    → As documented in `evidence/system4_orchestration/hot_state_size.txt`, `data/hot_state.json` maintains a compact size of 643 bytes[cite: 7]. For a system running once per shift indefinitely, keeping hot state small prevents token inflation, eliminates context degradation over long-running deployments, and minimizes database query overhead across shifts[cite: 7].

---

## Part 2 – Synthesis

*Graded on connecting two or more systems. Cite a named file/artifact from each.*

14. **Three layers.**
    → **Model:** `evidence/system1_agentic_loop/claim_01_kitchen_fire.jsonl` demonstrates the raw LLM inference layer generating completion responses[cite: 10].
    → **Harness:** `evidence/system3_claude_config/validator_output.txt` enforces structured constraints, tool definitions, and system prompts guiding the model's environment[cite: 6, 10].
    → **Orchestration:** `evidence/system4_orchestration/shift_run_output.txt` manages multi-step execution flow, cross-session state persistence, and shift scheduling[cite: 7, 10].

15. **Deterministic vs prompt.**
    → **Deterministic:** `evidence/system3_claude_config/claude_dir_structure.txt` and `evidence/system3_claude_config/evidence_rule_skill.md` demonstrate rigid tool permissions and rule validation enforced directly in code[cite: 6, 10]. This is right for safety-critical guardrails, file permissions, and atomic database writes[cite: 6].
    → **Prompt:** `evidence/system1_agentic_loop/summary.md` relies on natural language instructions to guide the decomposition strategy[cite: 10]. This is right for creative tasks, flexible problem decomposition, and nuanced reasoning where exact code rules are too rigid[cite: 10].

16. **Context, two faces.**
    → System 2 manages intra-session context by applying compression budgets (tracked in `evidence/system2_context_strategy/budget.json` and evaluated in `evidence/system2_context_strategy/eval.jsonl`) to keep active tokens under strict window limits during a single run[cite: 10]. System 4 manages cross-session context by externalizing state to disk, keeping `data/hot_state.json` at 643 bytes (cited in `evidence/system4_orchestration/hot_state_size.txt`) and appending incremental logs in `evidence/system4_orchestration/scratchpad_line.jsonl`[cite: 7, 10]. Both follow the core principle of context budget management—preventing token bloat—but System 2 uses inline pruning while System 4 uses external persistent state[cite: 7, 10].