# Run summary — 20260928_145943

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1707** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 4 | 0 | 14934 | 1122 | 0.0205 | 12.7 |
| claim_02_stolen_bike | routed | theft | low | 4 | 0 | 13314 | 770 | 0.0172 | 11.9 |
| claim_03_water_damage | routed | property_damage | medium | 5 | 1 | 17860 | 1199 | 0.0239 | 20.2 |
| claim_04_neighbor_injury | routed | liability | medium | 3 | 0 | 10276 | 1008 | 0.0153 | 13.3 |
| claim_05_auto_collision | routed | auto | high | 5 | 0 | 17529 | 1097 | 0.023 | 12.2 |
| claim_06_low_confidence_escalation | routed | property_damage | high | 6 | 1 | 22946 | 1613 | 0.031 | 26.4 |
| claim_07_tree_falls_on_car | routed | auto | medium | 4 | 0 | 14733 | 1140 | 0.0204 | 12.8 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14408 | 987 | 0.0193 | 12.5 |
